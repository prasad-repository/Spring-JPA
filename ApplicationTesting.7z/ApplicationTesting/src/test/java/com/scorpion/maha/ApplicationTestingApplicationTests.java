package com.scorpion.maha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
